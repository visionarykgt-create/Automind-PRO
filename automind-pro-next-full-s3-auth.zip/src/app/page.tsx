export default function Home() {
  return (
    <section className="grid gap-6">
      <div className="card text-center">
        <h1 className="text-3xl font-semibold">Venda mais veículos com o Automind PRO</h1>
        <p className="mt-2 text-neutral-300">Site pronto, estoque, leads e checkout Cartpanda.</p>
        <div className="mt-4">
          <a href="/inventory" className="btn">Ver Estoque</a>
        </div>
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        {["Site da Loja", "Gestão de Leads", "Checkout Rápido"].map((t,i)=>(
          <div key={i} className="card">
            <h3 className="font-semibold text-lg">{t}</h3>
            <p className="text-neutral-300">Solução simples e direta para você começar hoje.</p>
          </div>
        ))}
      </div>
    </section>
  );
}
