"use client";
import { signIn } from "next-auth/react";
import { useState } from "react";

export default function Login() {
  const [email, setEmail] = useState("admin@demo.com");
  const [password, setPassword] = useState("admin123");

  return (
    <form
      onSubmit={async (e)=>{ e.preventDefault(); await signIn("credentials",{ email, password, callbackUrl: "/admin"});}}
      className="card max-w-md mx-auto"
    >
      <h2 className="text-xl font-semibold">Entrar</h2>
      <label className="label mt-3">Email</label>
      <input className="input" value={email} onChange={e=>setEmail(e.target.value)} />
      <label className="label mt-3">Senha</label>
      <input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button className="btn mt-4" type="submit">Entrar</button>
    </form>
  );
}
