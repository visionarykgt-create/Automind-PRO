import { NextResponse } from "next/server";
import { putPublicImage } from "@/lib/s3";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) {
    return new NextResponse("Arquivo ausente", { status: 400 });
  }
  const url = await putPublicImage(file);
  return NextResponse.json({ url });
}
