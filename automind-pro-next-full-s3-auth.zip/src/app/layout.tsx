import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "Automind PRO",
  description: "SaaS automotivo — Next.js + Prisma + NextAuth + S3 + Cartpanda",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen bg-neutral-950 text-neutral-100">
        <header className="border-b border-neutral-800">
          <div className="container py-4 flex items-center justify-between">
            <Link href="/" className="font-bold">Automind PRO</Link>
            <nav className="flex gap-4 text-sm">
              <Link href="/inventory">Estoque</Link>
              <Link href="/admin">Admin</Link>
            </nav>
          </div>
        </header>
        <main className="container py-8">{children}</main>
        <footer className="container py-12 text-xs text-neutral-400">
          <p>© {new Date().getFullYear()} Automind PRO</p>
        </footer>
      </body>
    </html>
  );
}
